import axios from "axios";

const BASE_URL = "https://asset-verify.herokuapp.com/api/v1/loan";



export const GetLoans = async () => {
    try {
        const { data } = await axios.get("https://asset-verify.herokuapp.com/api/v1/loans")
        return data
    } catch (error) {
        return error.message
    }
}

class LoanService {
    getLoans() {
        return axios.get("https://asset-verify.herokuapp.com/api/v1/loans");
    }

    createLoan(loan) {
        return axios.post(BASE_URL, loan);
    }

    geLoanById(loanId) {
        return axios.get(BASE_URL + "/" + loanId);
    }

    updateLoan(loan, loanId) {
        return axios.put(BASE_URL + "/" + loanId, loan);
    }
    updateLoans(loan, loanId) {
        return axios.patch(BASE_URL + "/" + loanId, loan);
    }

    deleteLoan(loanId) {
        return axios.delete(BASE_URL + "/" + loanId);
    }
}
export default new LoanService();