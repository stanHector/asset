import React, { Component } from "react";
import AssetService from "../services/AssetService";

class UpdateAsset extends Component {
    constructor(props) {
        super(props);

        this.state = {
            id: this.props.match.params.id,
            company: "",
            project: "",
            itemName: "",
            category: "",
            assetTag: "",
            serialnumber: "",
            manufacturer: "",
            model: "",
            status: "",
            states: "",
            location: "",
            condition: "",
            firstname: "",
            lastname: "",
            email: "",
            checkedAsset: "",
            loading: false,
        };

        this.changeCompanyHandler = this.changeCompanyHandler.bind(this);
        this.changeProjectHandler = this.changeProjectHandler.bind(this);
        this.changeItemNameHandler = this.changeItemNameHandler.bind(this);
        this.handleConditionHandler = this.handleConditionHandler.bind(this);
        this.changeCategoryHandler = this.changeCategoryHandler.bind(this);
        this.changeAssetTagHandler = this.changeAssetTagHandler.bind(this);
        this.changeSerialnumberHandler = this.changeSerialnumberHandler.bind(this);
        this.changeManufacturerHandler = this.changeManufacturerHandler.bind(this);
        this.changeModelHandler = this.changeModelHandler.bind(this);
        this.changeStatusHandler = this.changeStatusHandler.bind(this);
        this.handleStatesHandler = this.handleStatesHandler.bind(this);
        this.changeLocationHandler = this.changeLocationHandler.bind(this);
        this.handleFirstnameHandler = this.handleFirstnameHandler.bind(this);
        this.handleLastnameHandler = this.handleLastnameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.handleSelectCheckedAsset = this.handleSelectCheckedAsset.bind(this);

        this.updateAsset = this.updateAsset.bind(this);
    }

    componentDidMount() {
        AssetService.getAssetById(this.state.id).then((res) => {

            let asset = res.data;

            this.setState({
                company: asset.company,
                project: asset.project,
                itemName: asset.itemName,
                category: asset.category,
                assetTag: asset.assetTag,
                serialnumber: asset.serialnumber,
                manufacturer: asset.manufacturer,
                model: asset.model,
                status: asset.status,
                states: this.state.states,
                location: asset.location,
                condition: asset.condition,
                firstname: asset.firstname,
                lastname: asset.lastname,
                email: asset.email,
                // assetStatus: asset.assetStatus,
                checkedAsset: asset.checkedAsset,
            });
        })
        console.log(this.state.firstname);
    }


    updateAsset = (e) => {
        e.preventDefault();
        this.setState({ loading: true })
        let asset = {
            company: this.state.company,
            itemName: this.state.itemName,
            category: this.state.category,
            assetTag: this.state.assetTag,
            serialnumber: this.state.serialnumber,
            manufacturer: this.state.manufacturer,
            model: this.state.model,
            status: this.state.status,
            states: this.state.states,
            location: this.state.location,
            condition: this.state.condition,
            firstname: this.state.firstname,
            lastname: this.state.lastname,
            email: this.state.email,
            // assetStatus: this.state.assetStatus,
            checkedAsset: this.state.checkedAsset,

        };
        // console.log("asset => " + JSON.stringify(asset));

        AssetService.updateAsset(asset, this.state.id).then((res) => {
            this.props.history.push("/assets");
        });
    };

    changeCompanyHandler = (event) => {
        this.setState({ company: event.target.value });
    };

    changeItemNameHandler = (event) => {
        this.setState({ itemName: event.target.value });
    };

    changeCategoryHandler = (event) => {
        this.state({ category: event.target.value });
    };

    changeAssetTagHandler = (event) => {
        this.setState({ assetTag: event.target.value });
    };

    changeModelHandler = (event) => {
        this.setState({ model: event.target.value });
    };

    changeStatusHandler = (event) => {
        this.setState({ status: event.target.value });
    };

    handleStatesHandler = (event) => {
        this.setState({ states: event.target.value });
    };


    changeLocationHandler = (event) => {
        this.setState({ location: event.target.value });
    };

    handleConditionHandler = (event) => {
        this.setState({ condition: event.target.value });
    };


    handleFirstnameHandler = (event) => {
        this.setState({ firstname: event.target.value });
    };

    handleLastnameHandler = (event) => {
        this.setState({ lastname: event.target.value });
    };

    changeEmailHandler = (event) => {
        this.setState({ email: event.target.value });
    };
    handleSelectCheckedAsset = (event) => {
        this.setState({ checkedAsset: event.target.value });
    };

    handlelocationHandler = (event) => {
        this.setState({ location: event.target.value });
    };
    changeSerialnumberHandler = (event) => {
        this.setState({ serialnumber: event.target.value });
    };

    changeManufacturerHandler = (event) => {
        this.setState({ manufacturer: event.target.value });
    };

    changeProjectHandler = (event) => {
        this.setState({ project: event.target.value });
    };

    // changeAssetStatusHandler = (event) => {
    //     this.setState({ assetStatus: event.target.value });
    // };

    cancel() {
        this.props.history.push("/assets");
    }

    render() {
        return (
            <>
                <div className="container" style={{ marginTop: "15px", padding: "50px" }}>
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">
                            <h3 className="text-center" style={{ marginTop: "25px", fontFamily: "cursive", fontWeight: "bold" }}>Update Asset</h3>
                            <div className="card-body">
                                <form>
                                    <div className="container">
                                        <div className="form-group">
                                            <label style={{ marginLeft: "15px", fontWeight: "bold", fontSize: "15px" }}>Company</label>
                                            <div className="col-sm-12">
                                                <input placeholder="Company" name="company" className="form-control" value={this.state.company} onChange={this.changeCompanyHandler} />
                                            </div>
                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Project </label>
                                            <div className="col-sm-12">
                                                <input placeholder="Project" name="project" className="form-control" value={this.state.project} onChange={this.changeProjectHandler} />
                                            </div>

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Asset name </label>
                                            <div className="col-sm-12">
                                                <input placeholder="Asset name" name="itemName" className="form-control" value={this.state.itemName} onChange={this.changeItemNameHandler} />
                                            </div>
                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Category </label>
                                            <div className="col-sm-12">
                                                <input placeholder="Category" name="category" className="form-control" value={this.state.category} onChange={this.changeCategoryHandler} />
                                            </div>
                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Asset Tag </label>
                                            <div className="col-sm-12">
                                                <input placeholder="Asset Tag" name="assetTag" className="form-control" value={this.state.assetTag} onChange={this.changeAssetTagHandler} />
                                            </div>
                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}> Serial number</label>
                                            <div className="col-sm-12">
                                                <input placeholder="Serial Number" name="serialnumber" className="form-control" value={this.state.serialnumber} onChange={this.changeSerialnumberHandler} />
                                            </div>

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Manufacturer</label>
                                            <div className="col-sm-12">
                                                <input name="manufacturer" className="form-control" value={this.state.manufacturer} onChange={this.changeManufacturerHandler} />
                                            </div>

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Model</label>
                                            <div className="col-sm-12">
                                                <input name="model" className="form-control" value={this.state.model} onChange={this.changeModelHandler} />
                                            </div>

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Firstname</label>
                                            <div className="col-sm-12">
                                                <input name="firstname" className="form-control" value={this.state.firstname} onChange={this.handleFirstnameHandler} />
                                            </div>

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Lastname</label>
                                            <div className="col-sm-12">
                                                <input name="lastname" className="form-control" value={this.state.lastname} onChange={this.handleLastnameHandler} />
                                            </div>

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Email</label>
                                            <div className="col-sm-12">
                                                <input name="email" type="email" className="form-control" value={this.state.email} onChange={this.changeEmailHandler} />
                                            </div>

                                            <div className="col-12" style={{ marginTop: "15px" }}>
                                                <select className="form-select" onChange={this.changeStatusHandler}>
                                                    <option defaultValue>Select asset status</option>
                                                    <option checkedAsset="1">Deployed</option>
                                                    <option checkedAsset="2">Broken/Bad</option>
                                                    <option checkedAsset="3">Obsolete</option>
                                                    <option checkedAsset="4">Returned</option>
                                                </select>
                                            </div>
                                            {/* <div className="col-12" style={{ marginTop: "15px" }}>
                                                <select className="form-select" onChange={this.handleConditionHandler}>
                                                    <option defaultValue>Select asset condition</option>
                                                    <option condition="1">A1(New)</option>
                                                    <option condition="2">A2(Good)</option>
                                                    <option condition="3">A3(Fair)</option>
                                                    <option condition="4">F1(Poor/Minor repair)</option>
                                                    <option condition="5">F2(Bad/Major repair)</option>
                                                    <option condition="6">F3(Unserviceable)</option>
                                                </select>
                                            </div> */}

                                            {/* <div className="col-sm-12" style={{ marginTop: "10px" }} >
                                                <select className="form-select" onChange={this.handleStatesHandler}>
                                                    <option defaultValue>Select state</option>
                                                    <option states="1">FCT</option>
                                                    <option states="2">Abia</option>
                                                    <option states="3">Adamawa</option>
                                                    <option states="4">Akwa Ibom</option>
                                                    <option states="5">Anambra</option>
                                                    <option states="6">Bauchi</option>
                                                    <option states="7">Bayelsa</option>
                                                    <option states="8">Benue</option>\
                                                    <option states="9">Borno</option>
                                                    <option states="10">Cross-River</option>
                                                    <option states="11">Delta</option>
                                                    <option states="12">Ebonyi</option>
                                                    <option states="13">Edo</option>
                                                    <option states="14">Ekiti</option>
                                                    <option states="15">Enugu</option>
                                                    <option states="16">Gombe</option>
                                                    <option states="17">Imo</option>
                                                    <option states="18">Jigawa</option>
                                                    <option states="19">Kaduna</option>
                                                    <option states="20">Kano</option>
                                                    <option states="21">Katsina</option>
                                                    <option states="22">Kebbi</option>
                                                    <option states="23">Kogi</option>
                                                    <option states="24">Kwara</option>
                                                    <option states="25">Lagos</option>
                                                    <option states="26">Nasarawa</option>
                                                    <option states="27">Niger</option>
                                                    <option states="28">Ogun</option>
                                                    <option states="29">Ondo</option>
                                                    <option states="31">Oyo</option>
                                                    <option states="32">Plateau</option>
                                                    <option states="33">Rivers</option>
                                                    <option states="34">Sokoto</option>
                                                    <option states="35">Taraba</option>
                                                    <option states="36">Yobe</option>
                                                    <option states="37">Zamfara</option>
                                                </select>
                                            </div> */}

                                            <label style={{ marginTop: "10px", marginLeft: "15px", fontWeight: "bold" }}>Location</label>
                                            <div className="col-sm-12">
                                                <input name="location"  className="form-control" value={this.state.location} onChange={this.handleLocationHandler} />
                                            </div>

                                            <div className="col-12" style={{ marginTop: "15px" }}>
                                                <select className="form-select" onChange={this.handleSelectCheckedAsset}>
                                                    <option defaultValue>Select checked type</option>
                                                    <option checkedAsset="1">Checked In</option>
                                                    <option checkedAsset="2">Checked Out</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div className="form-row text-center" style={{ marginTop: "12px" }} >
                                            <div className="col-12">
                                                <button className="btn btn-outline-success" onClick={this.updateAsset} >
                                                    {this.state.loading && <div className="spinner-border text-light" role="status"></div>}
                                                    Update Asset </button>

                                                <button className="btn btn-outline-danger" onClick={this.cancel.bind(this)} style={{ margin: "22px" }}>Cancel</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}

export default UpdateAsset;