import React, { Component } from "react";
import UserService from "../services/UserService";
import '../App.css';
import axios from 'axios';

class UsersList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            users: [],
            currentPage: 1,
            recordPerPage: 5,
        };

        this.createUser = this.createUser.bind(this);
        this.editUser = this.editUser.bind(this);
        this.deleteUser = this.deleteUser.bind(this);
        this.viewUser = this.viewUser.bind(this);
    }

    componentDidMount() {
        this.getUsersByPagination(this.state.currentPage);
    }
    getUsersByPagination(currentPage) {
        currentPage = currentPage - 1;
        axios.get("https://asset-verify.herokuapp.com/api/v1/users?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    users: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    }

    //Writing All the pagination functions
    //Show Next page
    showNextPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            this.getUsersByPagination(this.state.currentPage + 1);

        }
    };

    //Show Last Page
    showLastPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            this.getUsersByPagination(Math.ceil(this.state.totalElements / this.state.recordPerPage));
        }
    };
    //Show First page
    showFirstPage = () => {
        let firstPage = 1;
        if (this.state.currentPage > firstPage) {
            this.getUsersByPagination(firstPage);
        }
    };
    //Show previous page
    showPrevPage = () => {
        let prevPage = 1
        if (this.state.currentPage > prevPage) {
            this.getUsersByPagination(this.state.currentPage - prevPage);
        }
    };

    deleteUser(id) {
        UserService.deleteUser(id).then((res) => {
            this.setState({
                users: this.state.users.filter((user) => user.id !== id),
            });
        });
    }
    changePage = (event) => {
        this.setState({
            [event.target.name]: parseInt(event.target.value),
        });
    };


    editUser(id) {
        this.props.history.push(`/update-user/${id}`);
    }

    viewUser(id) {
        this.props.history.push(`/view-user/${id}`);
    }

    createUser() {
        this.props.history.push("/create-user");

    }

    cancel() {
        this.props.history.push("/dashboard");
    }

    render() {
        const { users, currentPage, totalPages, recordPerPage, search } = this.state;

        return (
            <>
                <div className="asset-list">
                    {/* <div className="row"> */}
                        {/* <div className="row"> */}
                        <div className="top">
                            <div className="topLeft">
                                {/* <img src={imgs} alt="img-logo" className="topAvatar" /> */}
                                <span className="logs" >Users</span>
                            </div>
            
                        </div>
                        <table className="table table-striped table-bordered">
                            <thead style={{ textAlign: "center", fontSize: "13px" }}>
                                <tr >
                                    {/* <th>#</th> */}
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Location</th>
                                    <th>Role</th>
                                    {/* <th colSpan="3">Action</th> */}
                                </tr>
                            </thead>
                            <tbody style={{ textAlign: "center", fontSize: "12px" }}>
                                {users.length === 0 ?
                                    <tr align="center"><td colSpan="6">No Record Found</td></tr> :

                                    users.map((user, index) => (
                                        <tr key={user.id}>
                                            {/* <td>{(recordPerPage * (currentPage - 1)) + index + 1}</td> */}
                                            <td>{user.firstname}</td>
                                            <td>{user.lastname}</td>
                                            <td>{user.email}</td>
                                            <td>{user.states}</td>
                                            <td>{user.userType}</td>
                                            {/* <td className="text-center"><Link to={`/update-user/${user.id}`} className="fas fa-edit"><Edit /></Link></td>
                                            <td className="text-center"><i onClick={() => this.deleteUser(user.id)} className="fa fa-trash" style={{ color: "red" }} ><Delete /> </i></td>
                                            <td className="text-center"><Link to={`/view-user/${user.id}`} className="view" style={{ alignItem: "center", color: "green" }}> <Visibility /></Link> </td> */}
                                        </tr>
                                    ))}
                            </tbody>
                        </table>
                        <table className="table">
                            <div style={{ float: 'left', fontFamily: 'monospace', color: '#0275d8' }}>
                                Page {currentPage} of {totalPages}
                            </div>
                            <div style={{ float: 'right' }}>
                                <div className="clearfix"></div>
                                <nav aria-label="Page navigation example">
                                    <ul className="pagination">
                                        <li className="page-item"><a type="button" className="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showPrevPage}>Previous</a></li>
                                        <li className="page-item"><a type="button" className="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showFirstPage}>First</a></li>
                                        <li className="page-item"><a type="button" className="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showNextPage}>Next</a></li>
                                        <li className="page-item"><a type="button" className="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showLastPage}>Last</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </table>
                    </div>
    
            </>
        );
    }
}

export default UsersList;
