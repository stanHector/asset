import React from 'react'
import './featuredInfo.css'


export default function FeatureInfo({ isLoading, allAssets, items }) {
    const user = JSON.parse(localStorage.getItem('user'));
    const userCount = allAssets?.map((state) => state.states)?.filter((x) => x === user?.state)
    const checkout = allAssets?.map((x) => x.status)?.filter((x) => x === 'Deployed');
    const brokenAssets = allAssets?.map((x) => x.status)?.filter((x) => x === 'Broken/Bad');
    const itemsInUse = items?.map((y) => y.status)?.filter((y) => y === 'Deployed')

    const userState = user.state;
    const stateAsset = allAssets.map((x) => x).filter((x) => x.states === userState);
    const deployCount = stateAsset.map((x) => x.status).filter((x) => x === 'Deployed');
    const brokenAssetsCount = stateAsset.map((x) => x.status).filter((x) => x === 'Broken/Bad');
    console.log(user.state)
    console.log()

    return (

        <>
            {/* {
                user !== 'User' && */}
            <div className='featured'>
                {/* <div className="featuredItem" style={{ backgroundColor: "#0EEEBE" }}>
                        <span className="featuredTitle"><PeopleOutline /> Users</span>
                        <div className="text-right" style={{ textAlign: "right", marginTop: "45px" }}>
                            <span className="featuredMoney">{user?.length}</span>
                        </div>
                    </div> */}

                <div className={isLoading ? "featuredLoading featuredItem" : "featuredItem"} style={{ backgroundColor: "#9FE2BF " }}>
                    {
                        isLoading ? (<div className="spinner-border text-primary dashboard-spinner" role="status"></div>)
                            :
                            (<>
                                <span className="featuredTitle">Total Assets</span>
                                <div className="text-right" style={{ textAlign: "right", marginTop: "45px" }}>
                                    <span className="featuredMoney">{user?.userType === "Admin" ? allAssets?.length : userCount?.length}</span>

                                </div>
                            </>)
                    }
                </div>
                <div className={isLoading ? "featuredLoading featuredItem" : "featuredItem"} style={{ backgroundColor: "#40E0D0" }}>
                    {
                        isLoading ? (<div className="spinner-border text-primary dashboard-spinner" role="status"></div>)
                            : (
                                <>
                                    <span className="featuredTitle">Total Assets Deployed</span>
                                    <div className="text-right" style={{ textAlign: "right", marginTop: "45px" }}>
                                        <span className="featuredMoney">{user?.userType === "Admin" ? checkout?.length : deployCount?.length}</span>

                                    </div>
                                </>
                            )
                    }
                </div>

                <div className={isLoading ? "featuredLoading featuredItem" : "featuredItem"} style={{ backgroundColor: "#6495ED" }}>
                    {
                        isLoading ? (<div className="spinner-border text-primary dashboard-spinner" role="status"></div>)
                            : (
                                <>
                                    <span className="featuredTitle">Total Items Deployed</span>
                                    <div className="text-right" style={{ textAlign: "right", marginTop: "45px" }}>
                                        <span className="featuredMoney">{itemsInUse?.length}</span>
                                    </div>
                                </>
                            )
                    }
                </div>

                <div className={isLoading ? "featuredLoading featuredItem" : "featuredItem"} style={{ backgroundColor: "#CCCCFF" }}>
                    {
                        isLoading ? (<div className="spinner-border text-primary dashboard-spinner" role="status"></div>)
                            : (
                                <>
                                    <span className="featuredTitle">Total Broken Assets</span>
                                    <div className="text-right" style={{ textAlign: "right", marginTop: "45px" }}>
                                        <span className="featuredMoney">{user?.userType === "Admin" ? brokenAssets?.length : brokenAssetsCount?.length}</span>
                                    </div>
                                </>
                            )
                    }
                </div>
            </div>
            {/* } */}
        </>
    )
}