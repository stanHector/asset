import axios from "axios";

const BASE_URL = "https://asset-verify.herokuapp.com/api/v1/item";


export const GetItems = async () => {
    try {
        const { data } = await axios.get("https://asset-verify.herokuapp.com/api/v1/items")
        return data
    } catch (error) {
        return error.message
    }
}

class ItemService {
    getItems() {
        return axios.get("https://asset-verify.herokuapp.com/api/v1/items");
    }


    getAllItems(){
        return axios.get("https://asset-verify.herokuapp.com/api/v1/all-items");
    }
    createItem(item) {
        return axios.post(BASE_URL, item);
    }

    getItemById(itemId) {
        return axios.get(BASE_URL + "/" + itemId);
    }

    updateItem(item, itemId) {
        return axios.put(BASE_URL + "/" + itemId, item);
    }
  
    deleteItem(itemId) {
        return axios.delete(BASE_URL + "/" + itemId);
    }
}
export default new ItemService();