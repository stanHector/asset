import React, { Component } from "react";
import '../App.css'
import AssetService from "../services/AssetService";
import axios from 'axios'

class AssetsList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            states: JSON.parse(localStorage.getItem('user')).states,
            assets: [],
            currentPage: 1,
            recordPerPage: 10,
        };
        this.createAsset = this.createAsset.bind(this);
        this.editAsset = this.editAsset.bind(this);
        this.deleteAsset = this.deleteAsset.bind(this);
        this.viewAsset = this.viewAsset.bind(this);
    }

    componentDidMount() {
        this.getAssetsByPagination(this.state.currentPage);
    }
    
    getAssetsByPagination(currentPage) {
        currentPage = currentPage - 1;
        axios.get("https://asset-verify.herokuapp.com/api/v1/assets?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    assets: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    }

    //Writing All the pagination functions
    //Show Next page
    showNextPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            this.getAssetsByPagination(this.state.currentPage + 1);
        }
    };

    //Show Last Page
    showLastPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            this.getAssetsByPagination(Math.ceil(this.state.totalElements / this.state.recordPerPage));
        }
    };

    //Show First page
    showFirstPage = () => {
        let firstPage = 1;
        if (this.state.currentPage > firstPage) {
            this.getAssetsByPagination(firstPage);
        }
    };

    //Show previous page
    showPrevPage = () => {
        let prevPage = 1
        if (this.state.currentPage > prevPage) {
            this.getAssetsByPagination(this.state.currentPage - prevPage);
        }
    };

    deleteAsset(id) {
        AssetService.deleteAsset(id).then((res) => {
            this.setState({
                assets: this.state.assets.filter((asset) => asset.id !== id),
            });
        });
    }

    editAsset(id) {
        this.props.history.push(`/update-asset/${id}`);
    }

    viewAsset(id) {
        this.props.history.push(`/view-asset/${id}`);
    }

    createAsset() {
        this.props.history.push("/create-asset");

    }

    cancel() {
        this.props.history.push("/dashboard");
    }

    render() {
        const { assets, currentPage, totalPages, recordPerPage } = this.state;
        const user = JSON.parse(localStorage.getItem('user'));
        const users = JSON.parse(localStorage.getItem('user'))?.userType;
        const userType = user?.userType;
        const userLocation = user?.result?.states;
        const userAssets = this.state?.assets.map((x) => x).filter((x) => x.states === userLocation);
        const data = userType !== 'User' ? this.state?.assets : userAssets;

        return (
            <div className="asset-list">
                <div className="top">
                    <div >
                        <span className="logs">My Assets</span>
                    </div>
                </div>

                <table className="table table-striped table-bordered">
                    <thead style={{ textAlign: "center", fontSize: "15px" }}>
                        <tr>
                            <th>No.</th>
                            <th>Company</th>
                            <th>Project</th>
                            <th>Asset name</th>
                            <th>Model</th>
                            <th>Asset tag</th>
                            <th>Serial number</th>
                            {/* <th>State</th>
                            <th>Location</th> */}
                            <th>Asset condition</th>
                            <th>Status</th>
                            <th>Firstname</th>
                            <th>Checked asset</th>
                        </tr>
                    </thead>
                    <tbody style={{ textAlign: "center", fontSize: "12px" }}>
                        {assets.length === 0 ?
                            <tr align="center"><td colSpan="12">No Record Found</td></tr> :
                            data?.map((asset, index) => (
                                <tr key={asset.id}>
                                    <td>{(recordPerPage * (currentPage - 1)) + index + 1}</td>
                                    {/* <td>{asset.id}</td> */}
                                    <td>{asset.company}</td>
                                    <td>{asset.project}</td>
                                    <td>{asset.itemName}</td>
                                    <td>{asset.model}</td>
                                    <td>{asset.assetTag}</td>
                                    <td>{asset.serialnumber}</td>
                                    {/* <td>{asset.states}</td>
                                    <td>{asset.location}</td> */}
                                    <td>{asset.condition}</td>
                                    <td>{asset.status}</td>
                                    <td>{asset.firstname}</td>
                                    <td>{asset.checkedAsset}</td>
                                </tr>
                            ))}
                    </tbody>
                </table>
                <table className="table">
                    <div style={{ float: 'left', fontFamily: 'monospace', color: '#0275d8' }}>
                        Page {currentPage} of {totalPages}
                    </div>
                    <div style={{ float: 'right' }}>
                        <div className="clearfix"></div>
                        <nav aria-label="Page navigation example">
                            <ul className="pagination">
                                <li className="page-item"><a type="button" className="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showPrevPage}>Previous</a></li>
                                <li className="page-item"><a type="button" className="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showFirstPage}>First</a></li>
                                <li className="page-item"><a type="button" className="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showNextPage}>Next</a></li>
                                <li className="page-item"><a type="button" className="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showLastPage}>Last</a></li>
                            </ul>
                        </nav>
                    </div>
                </table>
            </div>)
    }
}

export default AssetsList;