import React, { Component } from "react";
import '../App.css'
import AssetService from "../services/AssetService";
import { Link } from 'react-router-dom';
import { Visibility, Delete, Edit, CloudUploadOutlined, CloudDownloadOutlined, AddCircleOutlineSharp, AccountBalanceOutlined, SearchOutlined } from '@material-ui/icons'
import { CSVLink } from "react-csv";
import axios from 'axios'

const headers = [
  // { label: "Id", key: "id" },
  { label: "Company", key: "company" },
  { label: "Project", key: "project" },
  { label: "Asset name", key: "itemName" },
  { label: "Category", key: "category" },
  { label: "Asset Tag", key: "assetTag" },
  { label: "Serial number", key: "serialnumber" },
  { label: "Manufacturer", key: "manufacturer" },
  { label: "Model", key: "model" },
  { label: "Status", key: "status" },
  { label: "Condition", key: "condition" },
  { label: "State", key: "states" },
  { label: "Location", key: "location" },
  { label: "Firstname", key: "firstname" },
  { label: "Lastname", key: "lastname" },
  { label: "Email", key: "email" },
  { label: "Checked Asset", key: "checkedAsset" },
];

class AssetList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      states: JSON.parse(localStorage.getItem('user')).states,
      assets: [],
      currentPage: 1,
      recordPerPage: 20,
      search: '',
    };

    this.csvLinkEl = React.createRef();

    this.createAsset = this.createAsset.bind(this);
    this.editAsset = this.editAsset.bind(this);
    this.deleteAsset = this.deleteAsset.bind(this);
    this.viewAsset = this.viewAsset.bind(this);
  }

  componentDidMount() {
    this.getAssetsByPagination(this.state.currentPage);
  }
  getAssetsByPagination(currentPage) {
    currentPage = currentPage - 1;
    axios.get("https://asset-verify.herokuapp.com/api/v1/assets?page=" + currentPage + "&size=" + this.state.recordPerPage)
      .then(response => response.data).then((data) => {
        this.setState({
          assets: data.content,
          totalPages: data.totalPages,
          totalElements: data.totalElements,
          currentPage: data.number + 1
        });
      });
  }

  //Writing All the pagination functions
  //Show Next page
  showNextPage = () => {
    if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
      if (!this.state.search) {
        this.getAssetsByPagination(this.state.currentPage + 1);
      } else {
        this.searchAsset(this.state.currentPage + 1)
      }
    }
  };

  //Show Last Page
  showLastPage = () => {
    if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
      if (!this.state.search) {
        this.getAssetsByPagination(Math.ceil(this.state.totalElements / this.state.recordPerPage));
      }
      else {
        this.searchAsset(Math.ceil(this.state.totalElements / this.state.recordPerPage));
      }
    }
  };
  //Show First page
  showFirstPage = () => {
    let firstPage = 1;
    if (this.state.currentPage > firstPage) {
      if (!this.state.search) {
        this.getAssetsByPagination(firstPage);
      } else {
        this.searchAsset(firstPage)
      }
    }
  };

  //Show previous page
  showPrevPage = () => {
    let prevPage = 1
    if (this.state.currentPage > prevPage) {
      if (!this.state.search) {
        this.getAssetsByPagination(this.state.currentPage - prevPage);
      } else {
        this.searchAsset(this.state.currentPage - prevPage);
      }
    }
  };

  //Search Box Method
  searchBox = (e) => {
    this.setState({
      //assigning value to event target
      [e.target.name]: e.target.value,
    });
  };

  //Search Method Logic
  searchAsset = (currentPage) => {
    currentPage = currentPage - 1;
    axios.get("https://asset-verify.herokuapp.com/api/v1/assets/" + this.state.search + "?page=" + currentPage + "&size=" + this.state.recordPerPage)
      .then(response => response.data).then((data) => {
        this.setState({
          assets: data.content,
          totalPages: data.totalPages,
          totalElements: data.totalElements,
          currentPage: data.number + 1
        });
      });
  };

  //Reset Search Box
  resetAsset = (currentPage) => {
    this.setState({ "search": '' });
    this.getAssetsByPagination(currentPage);
  };

  deleteAsset(id) {
    AssetService.deleteAsset(id).then((res) => {
      this.setState({
        assets: this.state.assets.filter((asset) => asset.id !== id),
      });
    });
  }

  editAsset(id) {
    this.props.history.push(`/update-asset/${id}`);
  }

  viewAsset(id) {
    this.props.history.push(`/view-asset/${id}`);
  }

  createAsset() {
    this.props.history.push("/create-asset");
  }


  cancel() {
    this.props.history.push("/dashboard");
  }

  upload() {
    this.props.history.push("/upload-asset");
  }

  render() {
    const { assets, currentPage, totalPages, recordPerPage, search } = this.state;
    const user = JSON.parse(localStorage.getItem('user'));
    const users = JSON.parse(localStorage.getItem('user'))?.userType;
    const userType = user?.userType;
    const userLocation = user?.result?.states
    const userAssets = this.state?.assets?.map((x) => x).filter((x) => x.states === userLocation)
    const data = userType !== 'User' ? this.state.assets : userAssets;
   
    // console.log({
    //   userLocation,
    //   data,
    //   userAssets
    // })

    const downloadReport = async () => {
      this.setState({ data: data }, () => {
        setTimeout(() => {
          this.csvLinkEl.current.link.click();
        });
      });
    }

    return (
      <React.Fragment>
        <div className="asset-list">
          {/* <Topbar /> */}
          {/* <div className="row"> */}
          <div className="top">
            <div style={{ marginTop: "20px" }} >
              <span className="logs"> My Assets</span>
            </div>
            <div className="d-flex flex-row bd-highlight mb-3">
              <input style={{ borderRadius: "12px", marginTop: "20px", marginRight: "15px", marginLeft: "40px" }} type="text" className="form-control" name="search" size="100" placeholder="Search by asset tag or serial number or state or project" value={search} onChange={this.searchBox} />
              <button style={{ borderRadius: "12px", marginTop: "15px" }} type="button" name="search" className=" btn btn-outline-primary" onClick={this.searchAsset}><SearchOutlined /></button>
            </div>
            <div className="topRight">

              <button style={{ marginRight: "8px", margin: "10px" }} className="btn btn-primary float-lg-end" onClick={this.createAsset.bind(this)}>
                <AddCircleOutlineSharp />
              </button>

              <button style={{ marginRight: "8px" }} className="btn btn-primary float-lg-end" onClick={this.upload.bind(this)}>
                <CloudUploadOutlined />
              </button>

              <button style={{ marginRight: "8px" }} className="btn btn-primary float-lg-end" onClick={this.cancel.bind(this)}>
                <AccountBalanceOutlined />
              </button>

              <button style={{ marginRight: "8px" }} className="btn btn-primary float-lg-end" onClick={downloadReport}>
                <CloudDownloadOutlined />
              </button>
            </div>
          </div>

          <table className="table table-striped table-bordered">
            <thead style={{ textAlign: "center", fontSize: "11px" }}>
              <tr>
                <th>No.</th>
                <th>Company</th>
                <th>Project</th>
                <th>Category</th>
                <th>Asset name</th>
                <th>Model</th>
                <th>Asset tag</th>
                <th>Serial number</th>
                <th>State</th>
                <th>Location</th>
                <th>Asset condition</th>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Email</th>
                <th>Status</th>
                <th>Checked asset</th>
                <th colSpan="3">Actions</th>
              </tr>
            </thead>
            <tbody style={{ textAlign: "center", fontSize: "11px" }}>
              {assets.length === 0 ?
                <tr align="center"><td colSpan="17">No Record Found</td></tr> :
                data?.map((asset, index) => (
                  <tr key={asset?.id}>
                    <td>{(recordPerPage * (currentPage - 1)) + index + 1}</td>
                    {/* <td>{asset.id}</td> */}
                    <td>{asset.company}</td>
                    <td>{asset.project}</td>
                    <td>{asset.category}</td>
                    <td>{asset.itemName}</td>
                    <td>{asset.model}</td>
                    <td>{asset.assetTag}</td>
                    <td>{asset.serialnumber}</td>
                    <td>{asset.states}</td>
                    <td>{asset.location}</td>
                    <td>{asset.condition}</td>
                    <td>{asset.firstname}</td>
                    <td>{asset.lastname}</td>
                    <td>{asset.email}</td>
                    <td>{asset.status}</td>
                    <td>{asset.checkedAsset}</td>
                    <td className="text-center"><Link to={`/update-asset/${asset.id}`} className="edit"><Edit /></Link></td>
                    <td className="text-center"><i onClick={() => this.deleteAsset(asset.id)} className="fa fa-trash" style={{ color: "red" }} ><Delete /> </i></td>
                    <td className="text-center"><Link to={`/view-asset/${asset.id}`} className="view" style={{ alignItem: "center", color: "green" }}> <Visibility /></Link> </td>
                  </tr>
                ))}
            </tbody>
          </table>
          <table className="table">
            <div style={{ float: 'left', fontFamily: 'monospace', color: '#0275d8' }}>
              Page {currentPage} of {totalPages}
            </div>
            <div style={{ float: 'right' }}>
              <div className="clearfix"></div>
              <nav aria-label="Page navigation example">
                <ul className="pagination">
                  <li className="page-item"><a type="button" className="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showPrevPage}>Previous</a></li>
                  <li className="page-item"><a type="button" className="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showFirstPage}>First</a></li>
                  <li className="page-item"><a type="button" className="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showNextPage}>Next</a></li>
                  <li className="page-item"><a type="button" className="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showLastPage}>Last</a></li>
                </ul>
              </nav>
            </div>
          </table>

          <CSVLink
            headers={headers}
            filename="item_collection.csv"
            data={data}
            ref={this.csvLinkEl} />
          {/* </div> */}
        </div>
      </React.Fragment>
    )
  }
}

export default AssetList;