import React, { Component } from "react";
import AssetService from "../services/AssetService";

class CreatAsset extends Component {
  constructor(props) {
    super(props);

    this.state = {
      company: "",
      project: "",
      itemName: "",
      category: "",
      assetTag: "",
      serialnumber: "",
      manufacturer: "",
      model: "",
      status: "",
      states: "",
      location: "",
      condition: "",
      firstname: "",
      lastname: "",
      email: "",
      checkedAsset: "",
      loading: false,
    };

    this.changeCompanyHandler = this.changeCompanyHandler.bind(this);
    this.changeProjectHandler = this.changeProjectHandler.bind(this);
    this.changeItemNameHandler = this.changeItemNameHandler.bind(this);
    this.changeCategoryHandler = this.changeCategoryHandler.bind(this);
    this.changeAssetTagHandler = this.changeAssetTagHandler.bind(this);
    this.handleSerialHandler = this.handleSerialHandler.bind(this);
    this.handleManufacturerHandler = this.handleManufacturerHandler.bind(this);
    this.handleModelHandler = this.handleModelHandler.bind(this);
    this.handleStatusHandler = this.handleStatusHandler.bind(this);
    this.handleStatesHandler = this.handleStatesHandler.bind(this);
    this.handleLocationHandler = this.handleLocationHandler.bind(this);
    this.handleConditionHandler = this.handleConditionHandler.bind(this);
    this.handleFirstnameHandler = this.handleFirstnameHandler.bind(this);
    this.handleLastnameHandler = this.handleLastnameHandler.bind(this);
    this.handleEmailHandler = this.handleEmailHandler.bind(this);
    this.handleSelectCheckedAsset = this.handleSelectCheckedAsset.bind(this);

    this.addAsset = this.addAsset.bind(this);
  }
  addAsset = (e) => {
    e.preventDefault();
    this.setState({ loading: true })

    let asset = {
      company: this.state.company,
      project: this.state.project,
      itemName: this.state.itemName,
      category: this.state.category,
      assetTag: this.state.assetTag,
      serialnumber: this.state.serialnumber,
      manufacturer: this.state.manufacturer,
      model: this.state.model,
      status: this.state.status,
      states: this.state.states,
      location: this.state.location,
      condition: this.state.condition,
      firstname: this.state.firstname,
      lastname: this.state.lastname,
      email: this.state.email,
      checkedAsset: this.state.checkedAsset,

    };
    // console.log("user => " + JSON.stringify(user));
    if (this.state.company) {
      if (this.state.project) {
        if (this.state.itemName) {
          if (this.state.category) {
            if (this.state.assetTag) {
              if (this.state.serialnumber) {
                if (this.state.location) {
                  if (this.state.manufacturer) {
                    if (this.state.model) {
                      if (this.state.status) {
                        if (this.state.firstname) {
                          if (this.state.lastname) {
                            if (this.state.email) {
                              if (this.state.condition) {
                                if (this.state.states) {
                                  if (this.state.condition) {
                                    AssetService.createAsset(asset).then((res) => {
                                      this.setState({ loading: false })
                                      this.props.history.push("/assets");
                                    });
                                  } else {
                                    alert('Enter Asset Condition!')
                                    this.setState({ loading: false })
                                  }
                                } else {
                                  alert('Enter State!')
                                  this.setState({ loading: false })
                                }
                              } else {
                                alert('Enter Condition!')
                                this.setState({ loading: false })
                              }
                            } else {
                              alert('Enter Email!')
                              this.setState({ loading: false })
                            }
                          } else {
                            alert('Enter Lastname!')
                            this.setState({ loading: false })
                          }
                        }
                        else {
                          alert('Enter Firstname!')
                          this.setState({ loading: false })
                        }
                      }
                      else {
                        alert('Select Status!')
                        this.setState({ loading: false })
                      }
                    } else {
                      alert('Select Model!')
                      this.setState({ loading: false })
                    }
                  } else {
                    alert('Select Manufacturer!')
                    this.setState({ loading: false })
                  }
                } else {
                  alert('Select State!')
                  this.setState({ loading: false })
                }
              } else {
                alert('Enter Serial number!');
                this.setState({ loading: false })
              }
            } else {
              alert('Enter Asset tag! ')
              this.setState({ loading: false })
            }
          } else {
            alert('Enter category! ')
            this.setState({ loading: false })
          }
        } else {
          alert('Enter item name!')
          this.setState({ loading: false })
        }
      } else {
        alert('Enter company!')
        this.setState({ loading: false })
      }
    } else {
      alert('Enter project!')
      this.setState({ loading: false })
    }

  };


  changeCompanyHandler = (event) => {
    this.setState({ company: event.target.value });
  };

  changeProjectHandler = (event) => {
    this.setState({ project: event.target.value });
  };


  handleConditionHandler = (event) => {
    this.setState({ condition: event.target.value });
  };

  changeItemNameHandler = (event) => {
    this.setState({ itemName: event.target.value });
  };

  handleStatesHandler = (event) => {
    this.setState({ states: event.target.value });
  };

  changeCategoryHandler = (event) => {
    this.setState({ category: event.target.value });
  };
  changeAssetTagHandler = (event) => {
    this.setState({ assetTag: event.target.value });
  };

  handleSerialHandler = (event) => {
    this.setState({ serialnumber: event.target.value });
  };

  handleManufacturerHandler = (event) => {
    this.setState({ manufacturer: event.target.value });
  };
  handleModelHandler = (event) => {
    this.setState({ model: event.target.value });
  };
  handleStatusHandler = (event) => {
    this.setState({ status: event.target.value });
  };

  handleLocationHandler = (event) => {
    this.setState({ location: event.target.value });
  };

  handleFirstnameHandler = (event) => {
    this.setState({ firstname: event.target.value });
  };

  handleLastnameHandler = (event) => {
    this.setState({ lastname: event.target.value });
  };


  handleEmailHandler = (event) => {
    this.setState({ email: event.target.value });
  };

  handleSelectCheckedAsset = (event) => {
    this.setState({ checkedAsset: event.target.value });
  }

  cancel() {
    this.props.history.push("/assets");
  }

  render() {
    return (
      <React.Fragment>
        <div
          className="container"
          style={{ marginTop: "15px", padding: "50px" }}>
          <div className="row">
            <div className="card col-md-6 offset-md-3 offset-md-3">
              <h3 className="text-center" style={{ marginTop: "15px", fontFamily: "cursive", fontWeight: "bold" }}> Create Asset</h3>
              <div className="card-body">
                <form>
                  <div className="container">
                    <div className="form-group">
                      {/* <label style={{ marginTop: "10px" }}> First Name </label> */}
                      <div className="col-sm-12" >
                        <input placeholder="Company" name="company" className="form-control" value={this.state.company} onChange={this.changeCompanyHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Project" name="project" className="form-control" value={this.state.project} onChange={this.changeProjectHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Asset name" name="itemName" className="form-control" value={this.state.itemName} onChange={this.changeItemNameHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Category" name="category" className="form-control" value={this.state.category} onChange={this.changeCategoryHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Asset Tag" name="assetTag" className="form-control" value={this.state.assetTag} onChange={this.changeAssetTagHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Serial number" name="serialnumber" className="form-control" value={this.state.serialnumber} onChange={this.handleSerialHandler} />
                      </div>


                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Manufacturer" name="manufacturer" className="form-control" value={this.state.manufacturer} onChange={this.handleManufacturerHandler} />
                      </div>


                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Model" name="model" className="form-control" value={this.state.model} onChange={this.handleModelHandler} />
                      </div>

                      <div className="col-12" style={{ marginTop: "15px" }}>

                        <select className="form-select" onChange={this.handleStatusHandler}>
                          <option defaultValue>Status</option>
                          <option checkedAsset="1">Deployed</option>
                          <option checkedAsset="2">Broken/Bad</option>
                          <option checkedAsset="3">Obsolete</option>
                          <option checkedAsset="4">Returned</option>
                        </select>
                      </div>


                      <div className="col-12" style={{ marginTop: "15px" }}>
                        <select className="form-select" onChange={this.handleConditionHandler}>
                          <option defaultValue>Asset Condition</option>
                          <option condition="1">A1(New)</option>
                          <option condition="2">A2(Good)</option>
                          <option condition="3">A3(Fair)</option>
                          <option condition="4">F1(Poor/Minor repair)</option>
                          <option condition="5">F2(Bad/Major repair)</option>
                          <option condition="6">F3(Unserviceable)</option>
                        </select>
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Firstname" name="firstname" className="form-control" value={this.state.firstname} onChange={this.handleFirstnameHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Lastname" name="lastname" className="form-control" value={this.state.lastname} onChange={this.handleLastnameHandler} />
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Email" name="email" className="form-control" value={this.state.email} onChange={this.handleEmailHandler} />
                      </div>

                      <div className="col-12" style={{ marginTop: "15px", marginBottom: "15px" }} >
                        <select className="form-select" onChange={this.handleStatesHandler}>
                          <option states="1">FCT</option>
                          <option states="2">Abia</option>
                          <option states="3">Adamawa</option>
                          <option states="4">Akwa Ibom</option>
                          <option states="5">Anambra</option>
                          <option states="6">Bauchi</option>
                          <option states="7">Bayelsa</option>
                          <option states="8">Benue</option>\
                          <option states="9">Borno</option>
                          <option states="10">Cross-River</option>
                          <option states="11">Delta</option>
                          <option states="12">Ebonyi</option>
                          <option states="13">Edo</option>
                          <option states="14">Ekiti</option>
                          <option states="15">Enugu</option>
                          <option states="16">Gombe</option>
                          <option states="17">Imo</option>
                          <option states="18">Jigawa</option>
                          <option states="19">Kaduna</option>
                          <option states="20">Kano</option>
                          <option states="21">Katsina</option>
                          <option states="22">Kebbi</option>
                          <option states="23">Kogi</option>
                          <option states="24">Kwara</option>
                          <option states="25">Lagos</option>
                          <option states="26">Nasarawa</option>
                          <option states="27">Niger</option>
                          <option states="28">Ogun</option>
                          <option states="29">Ondo</option>
                          <option states="31">Oyo</option>
                          <option states="32">Plateau</option>
                          <option states="33">Rivers</option>
                          <option states="34">Sokoto</option>
                          <option states="35">Taraba</option>
                          <option states="36">Yobe</option>
                          <option states="37">Zamfara</option>
                        </select>
                      </div>

                      <div className="col-sm-12" style={{ marginTop: "10px" }}>
                        <input placeholder="Location" name="location" className="form-control" value={this.state.location} onChange={this.handleLocationHandler} />
                      </div>

                      <div className="col-12" style={{ marginTop: "15px" }}>
                        <label style={{ fontWeight: "bold" }}>Checked Asset</label>

                        <select className="form-select" onChange={this.handleSelectCheckedAsset}>
                          <option defaultValue>Select Checked Type</option>
                          <option checkedAsset="1">Checked In</option>
                          <option checkedAsset="2">Checked Out</option>
                        </select>
                      </div>
                    </div>
                    <div className="form-row text-center" style={{ marginTop: "12px" }}>
                      <div className="col-12">
                        <button className="btn btn-outline-primary" onClick={this.addAsset} disabled={this.state.loading}>
                          {this.state.loading && <div className="spinner-border text-light" role="status"></div>}

                          Add Asset
                        </button>

                        <button className="btn btn-outline-danger" onClick={this.cancel.bind(this)} style={{ margin: "22px" }}>Cancel</button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
export default CreatAsset